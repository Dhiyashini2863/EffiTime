import axios from 'axios';

const API_URL = 'http://your-api-url/api/'; // Replace with your API URL

export const getLeaveDays = async (empId) => {
    return axios.get(`${API_URL}leavedays/`, {
        params: { empId }
    });
};

export const applyLeave = async (leaveData) => {
    return axios.post(`${API_URL}leavedays/`, leaveData);
};

// Add more methods as needed (update, delete, etc.)
