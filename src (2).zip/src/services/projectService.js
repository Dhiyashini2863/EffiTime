import axios from 'axios';

const API_URL = 'http://localhost:8000/api/'; // Replace with your API URL

export const getProjects = async () => {
    return axios.get(`${API_URL}projects/`);
};

export const addProject = async (projectData) => {
    return axios.post(`${API_URL}projects/`, projectData);
};

// Add more methods as needed (update, delete, etc.)
