import React, { useEffect, useState } from 'react';
import axios from 'axios';

const LeadDashboard = () => {
    const [timesheets, setTimesheets] = useState([]);
    const userId = localStorage.getItem('userId');

    useEffect(() => {
        const fetchTimesheets = async () => {
            const res = await axios.get('/api/timesheets');
            setTimesheets(res.data);
        };

        fetchTimesheets();
    }, []);

    const handleApproval = async (timesheetId, status) => {
        await axios.post(`/api/timesheets/${timesheetId}/lead-approval`, { status });
        // Re-fetch timesheets after approval
        const res = await axios.get('/api/timesheets');
        setTimesheets(res.data);
    };

    return (
        <div className="lead-dashboard">
            <h1>Lead Dashboard</h1>
            {/* Display timesheets with Lead Approval buttons */}
            {timesheets.map(timesheet => (
                <div key={timesheet.id}>
                    {/* Timesheet details */}
                    <button onClick={() => handleApproval(timesheet.id, 'Approved')}>Approve</button>
                    <button onClick={() => handleApproval(timesheet.id, 'Rejected')}>Reject</button>
                </div>
            ))}
        </div>
    );
};

export default LeadDashboard;
