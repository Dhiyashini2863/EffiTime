import React, { useCallback, useEffect, useState } from "react";
import { useAuth } from "../context/AuthContext";
import "./Dashboard.css";

const Dashboard = () => {
  document.title="Dashboard|Employee";
  const [employee, setEmployee] = useState(null);
  const [leaveDays, setLeaveDays] = useState(0);
  const { empId } = useAuth();
  const currentMonth = new Date().getMonth();
  const currentYear = new Date().getFullYear();
  const today = new Date();
  today.setHours(0, 0, 0, 0); // Set time to the start of the day for accurate comparison

  // Memoize fetchEmployeeDetails function
  const fetchEmployeeDetails = useCallback(async () => {
    try {
      const response = await fetch(
        `http://127.0.0.1:8000/api/employee/${empId}/`
      );
      if (response.ok) {
        const employeeData = await response.json();
        setEmployee(employeeData);
        fetchTimesheets(employeeData.joining_date);
      } else {
        alert("Error fetching employee details");
      }
    } catch (error) {
      alert("Error fetching employee details");
    }
  }, [empId]);

  // Fetch timesheets based on employee ID and current month/year
  const fetchTimesheets = async (joiningDate) => {
    try {
      const response = await fetch(
        `http://127.0.0.1:8000/api/timesheet/?emp=${empId}&month=${
          currentMonth + 1
        }&year=${currentYear}`
      );
      if (response.ok) {
        const timesheetData = await response.json();
        calculateLeaveDays(timesheetData, joiningDate);
      } else {
        alert("Error fetching timesheets");
      }
    } catch (error) {
      alert("Error fetching timesheets");
    }
  };

  // Calculate leave days based on timesheets and joining date
  const calculateLeaveDays = (timesheets, joiningDate) => {
    const joining = new Date(joiningDate);
    const startDay =
      joining.getMonth() === currentMonth &&
      joining.getFullYear() === currentYear
        ? joining.getDate()
        : 1;
    const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
    const updatedDates = timesheets.map((ts) => new Date(ts.date).getDate());

    const leaveDaysCount = Array.from(
      { length: daysInMonth - startDay + 1 },
      (_, i) => i + startDay
    ).filter((day) => {
      const date = new Date(currentYear, currentMonth, day);
      const isSunday = date.getDay() === 0;
      return date < today && !updatedDates.includes(day) && !isSunday;
    }).length;

    setLeaveDays(leaveDaysCount);
  };

  // useEffect to fetch employee details when empId changes
  useEffect(() => {
    if (empId) {
      fetchEmployeeDetails();
    } else {
      alert("Employee ID not found");
    }
  }, [empId, fetchEmployeeDetails]); // Dependency array includes empId and fetchEmployeeDetails

  return (
    <div className="dashboard-container">
      <div className="dashboard-content">
        <h1>Welcome, {employee ? employee.emp_name : "Loading..."}</h1>
        <p>Employee ID: {empId}</p>
        <p>Your Total Leave days of this Month: {leaveDays}</p>
      </div>
    </div>
  );
};

export default Dashboard;
