import React, { useState } from "react";
import LeadSidebar from "./LeadSidebar";
import Home from "./Home";
import LeadPage from "./LeadPage";
import "./LeadDashboard.css";

const LeadDashboard = () => {
  document.title="Dashboard|Lead";
  const [activeComponent, setActiveComponent] = useState("home");

  const renderContent = () => {
    switch (activeComponent) {
      case "home":
        return <Home />;
      case "view-timesheet":
        return <LeadPage />;
      default:
        return <Home />;
    }
  };

  return (
    <div className="lead-dashboard">
      <LeadSidebar setActiveComponent={setActiveComponent} />
      <div className="lead-content">{renderContent()}</div>
    </div>
  );
};

export default LeadDashboard;
