import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './ManagerPage.css'; // Ensure correct path for styling
import { FaSignOutAlt } from 'react-icons/fa'; // Import the logout icon

const ManagerPage = () => {
    const [timesheets, setTimesheets] = useState([]);
    const [filteredTimesheets, setFilteredTimesheets] = useState([]);
    const [selectedDate, setSelectedDate] = useState(null);
    const [employeeIdFilter, setEmployeeIdFilter] = useState('');

    useEffect(() => {
        fetchTimesheets();
    }, []);

    const fetchTimesheets = async () => {
        try {
            const response = await axios.get('http://localhost:8000/api/manager-timesheets/');
            setTimesheets(response.data);
            setFilteredTimesheets(response.data);
        } catch (error) {
            console.error('Error fetching timesheets:', error);
        }
    };

    const handleApproval = async (timesheetId, approvalStatus) => {
        try {
            await axios.put(`http://localhost:8000/api/manager-timesheets/${timesheetId}/`, {
                manager_approval: approvalStatus,
            });
            fetchTimesheets(); // Refresh timesheets after approval/rejection
        } catch (error) {
            console.error('Error updating timesheet:', error);
        }
    };

    const handleDateChange = (e) => {
        const inputDate = e.target.value;
        if (Date.parse(inputDate)) {
            const date = new Date(inputDate);
            const formattedDate = date.toISOString().split('T')[0];
            setSelectedDate(formattedDate);

            filterTimesheets(formattedDate, employeeIdFilter);
        } else {
            console.error('Invalid date value');
        }
    };

    const handleEmployeeIdChange = (e) => {
        const id = e.target.value;
        setEmployeeIdFilter(id);

        filterTimesheets(selectedDate, id);
    };

    const filterTimesheets = (date, empId) => {
        let filtered = timesheets;
        if (date) {
            filtered = filtered.filter(t => t.date === date);
        }
        if (empId) {
            filtered = filtered.filter(t => t.emp_id === empId);
        }
        setFilteredTimesheets(filtered);
    };

    const handleShowAll = () => {
        setSelectedDate(null);
        setEmployeeIdFilter('');
        setFilteredTimesheets(timesheets);
    };

    const handleLogout = () => {
        console.log('Logging out...');
        localStorage.removeItem('token'); // Clear authentication token
        localStorage.removeItem('empId');
        window.location.href = '/login'; // Redirect to login page
    };

    const formatTimestamp = (timestamp) => {
        const date = new Date(timestamp);
        return `${date.toISOString().split('T')[0]} ${date.toTimeString().split(' ')[0]}`;
    };

    const renderTimesheetDetails = () => {
        if (!filteredTimesheets.length) return <p>No entries available</p>;

        return (
            <div className="timesheet-details">
                <h3>{selectedDate ? `Timesheet Details for ${selectedDate}` : 'All Timesheet Entries'}</h3>
                <table>
                    <thead>
                        <tr>
                            <th>Employee ID</th>
                            <th>Employee Name</th>
                            <th>Date</th>
                            <th>Project Name</th>
                            <th>Start Time</th>
                            <th>End Time</th>
                            <th>Total Hours</th>
                            <th>Timestamp</th> {/* New column for timestamp */}
                            <th>Comments</th>
                            <th>Lead Approval</th>
                            <th>Manager Approval</th>
                           
                        </tr>
                    </thead>
                    <tbody>
                        {filteredTimesheets.map((timesheet) => (
                            <tr key={timesheet.id}>
                                <td>{timesheet.emp_id || 'N/A'}</td>
                                <td>{timesheet.emp_name || 'N/A'}</td>
                                <td>{timesheet.date}</td>
                                <td>{timesheet.project_name}</td>
                                <td>{timesheet.start_time}</td>
                                <td>{timesheet.end_time}</td>
                                <td>{timesheet.total_hours}</td>
                                <td>{formatTimestamp(timesheet.timestamp)}</td> {/* Format and display timestamp */}
                                <td>{timesheet.comments}</td>
                                <td>{timesheet.lead_approval}</td>
                                <td>
                                    {timesheet.manager_approval === 'pending' ? (
                                        <>
                                            <button onClick={() => handleApproval(timesheet.id, 'approved')}>Approve</button>
                                            <button onClick={() => handleApproval(timesheet.id, 'rejected')}>Reject</button>
                                        </>
                                    ) : (
                                        timesheet.manager_approval
                                    )}
                                </td>
                               
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        );
    };

    return (
        <div className="managerpage-container">
            <h1>Hello, Manager</h1>
            <button className="logoutbutton" onClick={handleLogout}>
                <FaSignOutAlt /> {/* Logout icon */}
            </button>
            <div className="filter-container">
                <div className="filter-box">
                    <input
                        id="employee-id-filter"
                        type="text"
                        value={employeeIdFilter}
                        onChange={handleEmployeeIdChange}
                        placeholder="Enter Employee ID"
                    />
                </div>
                <div className="date-selector">
                    <input
                        type="date"
                        onChange={handleDateChange}
                    />
                    <button onClick={handleShowAll}>Show All</button>
                </div>
            </div>
            {renderTimesheetDetails()}
        </div>
    );
};

export default ManagerPage;
