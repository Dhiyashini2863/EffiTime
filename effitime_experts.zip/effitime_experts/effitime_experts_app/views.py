from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from django.views import View
from django.http import JsonResponse
from django.shortcuts import get_object_or_404
from django.contrib.auth.hashers import make_password, check_password
from .models import Employee, Timesheet, Project
from .serializers import EmployeeSerializer, TimesheetSerializer, ProjectSerializer

class RegisterView(APIView):
    def post(self, request):
        data = request.data

        if data.get('password') != data.get('confirm_password'):
            return Response({"error": "Passwords do not match"}, status=status.HTTP_400_BAD_REQUEST)

        data['password'] = make_password(data['password'])
        serializer = EmployeeSerializer(data=data)

        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class LoginView(APIView):
    def post(self, request):
        data = request.data

        emp_id = data.get('emp_id')
        password = data.get('password')
        try:
            employee = Employee.objects.get(emp_id=emp_id)
            if check_password(password, employee.password):
                return Response({
                    "message": "Login successful",
                    "emp_id": employee.emp_id,
                    "emp_name": employee.emp_name,
                    "joining_date": employee.joining_date,
                    "person_status": employee.person_status
                }, status=status.HTTP_200_OK)
            else:
                return Response({"error": "Invalid password"}, status=status.HTTP_400_BAD_REQUEST)
        except Employee.DoesNotExist:
            return Response({"error": "Employee not found"}, status=status.HTTP_404_NOT_FOUND)

class EmployeeDetailView(View):
    def get(self, request, emp_id):
        try:
            employee = Employee.objects.get(emp_id=emp_id)
            employee_data = {
                'emp_id': employee.emp_id,
                'emp_name': employee.emp_name,
                'joining_date': employee.joining_date,
            }
            return JsonResponse(employee_data)
        except Employee.DoesNotExist:
            return JsonResponse({'error': 'Employee not found'}, status=404)

class TimesheetView(APIView):
    def get(self, request):
        emp_id = request.query_params.get('emp')
        if emp_id:
            timesheets = Timesheet.objects.filter(emp_id=emp_id)
        else:
            timesheets = Timesheet.objects.all()
        serializer = TimesheetSerializer(timesheets, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def post(self, request):
        data = request.data
        total_hours = calculate_total_hours(data['start_time'], data['end_time'])
        data['total_hours'] = total_hours

        serializer = TimesheetSerializer(data=data)
        if serializer.is_valid():
            timesheet = serializer.save()
            response_data = TimesheetSerializer(timesheet).data
            response_data['total_hours'] = total_hours
            return Response(response_data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class ViewTimesheetView(APIView):
    def get(self, request):
        timesheets = Timesheet.objects.all()
        serializer = TimesheetSerializer(timesheets, many=True)
        if request.content_type == 'application/json':
            return JsonResponse(serializer.data, safe=False)
        else:
            return render(request, 'view_timesheet.html', {'timesheets': serializer.data})


def calculate_total_hours(start_time, end_time):
    from datetime import datetime
    fmt = '%H:%M'
    start = datetime.strptime(start_time, fmt)
    end = datetime.strptime(end_time, fmt)
    total_hours = (end - start).seconds / 3600
    return round(total_hours, 2)


class LeadTimesheetView(APIView):
    def get(self, request):
        timesheets = Timesheet.objects.select_related('emp').all()
        serializer = TimesheetSerializer(timesheets, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def put(self, request, timesheet_id):
        timesheet = get_object_or_404(Timesheet, id=timesheet_id)
        data = request.data
        timesheet.lead_approval = data.get('lead_approval', timesheet.lead_approval)
        timesheet.save()
        serializer = TimesheetSerializer(timesheet)
        return Response(serializer.data, status=status.HTTP_200_OK)

class ManagerTimesheetView(APIView):
    def get(self, request):
        timesheets = Timesheet.objects.select_related('emp').all()
        serializer = TimesheetSerializer(timesheets, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def put(self, request, timesheet_id):
        timesheet = get_object_or_404(Timesheet, id=timesheet_id)
        data = request.data
        timesheet.manager_approval = data.get('manager_approval', timesheet.manager_approval)
        timesheet.save()
        serializer = TimesheetSerializer(timesheet)
        return Response(serializer.data, status=status.HTTP_200_OK)


class ProjectListView(APIView):
    def get(self, request):
        projects = Project.objects.all()
        serializer = ProjectSerializer(projects, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def post(self, request):
        data = request.data
        serializer = ProjectSerializer(data=data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
