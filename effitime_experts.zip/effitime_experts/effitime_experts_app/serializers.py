from rest_framework import serializers
from .models import Employee, Timesheet, Project
from django.contrib.auth.hashers import make_password

class EmployeeSerializer(serializers.ModelSerializer):
    class Meta:
        model = Employee
        fields = '__all__'


class TimesheetSerializer(serializers.ModelSerializer):
    emp_id = serializers.CharField(source='emp.emp_id', read_only=True)
    emp_name = serializers.CharField(source='emp.emp_name', read_only=True)
    emp = serializers.PrimaryKeyRelatedField(queryset=Employee.objects.all(), write_only=True)
    project_name = serializers.CharField(read_only=True)

    class Meta:
        model = Timesheet
        fields = ['id', 'emp', 'emp_id', 'emp_name', 'date', 'project_name', 'start_time', 'end_time', 'comments', 'total_hours', 'lead_approval', 'manager_approval', 'timestamp']


class ProjectSerializer(serializers.ModelSerializer):
    emp_id = serializers.CharField(source='emp.emp_id', read_only=True)
    emp_name = serializers.CharField(source='emp.emp_name', read_only=True)

    class Meta:
        model = Project
        fields = ['id', 'emp_id', 'emp_name', 'project_name', 'project_module', 'status', 'timestamp']
        read_only_fields = ['id', 'timestamp']
