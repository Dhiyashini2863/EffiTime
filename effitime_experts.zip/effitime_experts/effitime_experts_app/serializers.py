from rest_framework import serializers
from .models import Employee, Timesheet
from django.contrib.auth.hashers import make_password


class EmployeeSerializer(serializers.ModelSerializer):
    class Meta:
        model = Employee
        fields = '__all__'


class TimesheetSerializer(serializers.ModelSerializer):
    emp_id = serializers.CharField(source='emp.emp_id', read_only=True)
    emp_name = serializers.CharField(source='emp.emp_name', read_only=True)
    emp = serializers.PrimaryKeyRelatedField(queryset=Employee.objects.all(), write_only=True)

    class Meta:
        model = Timesheet
        fields = ['emp', 'emp_id', 'emp_name', 'date', 'project_name', 'start_time', 'end_time', 'comments', 'total_hours']





